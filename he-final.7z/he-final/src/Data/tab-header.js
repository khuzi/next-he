export const WeWashHeader = {
  label: "We Wash",
  src: "/images/We-Wash.png",
  intro:
    " Sulphuric Acid is a strong dibasic acid. in addition, it is also a strong oxidizing and dehydrating agent. It is one of the most widely employed chemicals and enters into many industries, though infrequently appearing in the finished material.",
};

export const HamzaChemicalsHeader = {
  label: "Hamza Chemicals",
  src: null,
  intro:
    " Sulphuric Acid is a strong dibasic acid. in addition, it is also a strong oxidizing and dehydrating agent. It is one of the most widely employed chemicals and enters into many industries, though infrequently appearing in the finished material.",
};

export const AgenciesData = {
  label: "Olympia Chemicals Limited",
  src: "/images/olympia.png",
  intro:
    "Hamza Enterprises is Olympia's only distribution company in Hyderabad. Soda ash light, Soda ash dense and Sodium bicarbonate are available in large quantity.",
};
