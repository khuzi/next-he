export const carouselData = [
  {
    src: "/images/img_1.jpg",
    txt1: "CHEMICAL MANUFACTURER FOR PAST 50 YEARS",
  },
  {
    src: "/images/img_2.jpg",
    txt1: "WE PRODUCE CHEMICALS FOR INDUSTRIAL USE.",
  },
  { src: "/images/img_3.jpg", txt1: "LOOKING INTO THE FUTURE." },
];
